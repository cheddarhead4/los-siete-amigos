from django.contrib import admin
from timecard.models import timecard

admin.site.register(timecard)