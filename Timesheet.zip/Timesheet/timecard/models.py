from django.db import models
from django.forms import ModelForm

# Create your models here.

class timecard(models.Model):
	name = models.CharField(default='User', max_length = 30)
	monTimeIn = models.TimeField(default='7:00')
	monLunchOut = models.TimeField(default='11:30')
	monLunchIn = models.TimeField(default='12:30')
	monTimeOut = models.TimeField(default='3:30')
	tuesTimeIn = models.TimeField(default='7:00')
	tuesLunchOut = models.TimeField(default='11:30')
	tuesLunchIn = models.TimeField(default='12:30')
	tuesTimeOut = models.TimeField(default='3:30')
	wedTimeIn = models.TimeField(default='7:00')
	wedLunchOut = models.TimeField(default='11:30')
	wedLunchIn = models.TimeField(default='12:30')
	wedTimeOut = models.TimeField(default='3:30')
	thursTimeIn = models.TimeField(default='7:00')
	thursLunchOut = models.TimeField(default='11:30')
	thursLunchIn = models.TimeField(default='12:30')
	thursTimeOut = models.TimeField(default='3:30')
	friTimeIn = models.TimeField(default='7:00')
	friLunchOut = models.TimeField(default='11:30')
	friLunchIn = models.TimeField(default='12:30')
	friTimeOut = models.TimeField(default='3:30')
	
class TimecardForm(ModelForm):
	class Meta:
		model = timecard