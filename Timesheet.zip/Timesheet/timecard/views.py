# Create your views here.
from django.shortcuts import render_to_response
from django.shortcuts import get_object_or_404
from django.shortcuts import get_list_or_404
from django.template import RequestContext
from timecard.models import TimecardForm
from timecard.models import timecard

def home(request):
	if request.method == 'POST':
		form = TimecardForm(request.POST)
		if form.is_valid():
			form.save()
	else:
		form = TimecardForm()
	
	return render_to_response('index.html', {'TimecardForm' : form}, context_instance=RequestContext(request))
	
def viewcard(request):
	cards = get_list_or_404(timecard)
	return render_to_response("viewcard.html", {'cards': cards})